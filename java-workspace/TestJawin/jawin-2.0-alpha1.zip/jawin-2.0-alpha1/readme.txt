Jawin - Java/Win32/COM interoperability project readme.
Jawin main page: http://jawinproject.sourceforge.net/

Version 2.0-alpha1, build 2005-03-23

To get started with Jawin, please see:
	docs/jawin.html

Jawin requires JDK 1.3 or newer.
		