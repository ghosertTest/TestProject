Browsers:
	The documentation have been tested with Mozilla 1.5 and IE 6.0. If you 
	have a problem reading the documentation with your specific browser, 
	please report it to the Jawin mailing list.


Accessibility:
	If you feel the default style of the documentation is using a too small 
	font-size, try using the alternative style "Standard fonts". This style 
	also uses only black/white colors.

	In Mozilla the style is changed from the "View/Use Style"-menu. IE does not 
	natively support changing the style, but this can be accomplished by using 
	the "Choose style sheet" favelet from http://www.favelets.com.


HTML-standard:
	The documentation have been validated as "HTML 4.01 Strict" with W3C's 
	"MarkUp Validation Service", located at:
		http://validator.w3.org